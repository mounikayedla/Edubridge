package com.example.JpaWithHibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    { 
    	Person p = new Person();
    	p.setPid(13);
    	p.setPname("Ajay");
    	p.setTech("Java");
      
    	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
    	EntityManager em = emf.createEntityManager();
    	
    	em.getTransaction().begin();
    	em.persist(p);
    	em.getTransaction().commit();
    	System.out.println(p);
    }
}
